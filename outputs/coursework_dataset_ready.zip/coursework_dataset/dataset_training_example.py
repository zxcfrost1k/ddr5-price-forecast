"""Example ML pipeline. Run after installing pandas and scikit-learn.

python3 dataset_training_example.py /path/to/coursework_dataset
Fits on train, compares against the last-price baseline on validation/test.
Uses only the feature allowlist. No random train/test split.
"""
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

folder=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
config=json.loads((folder/'feature_config.json').read_text())
numeric=config['numeric_features'];categorical=config['categorical_features'];features=numeric+categorical
train=pd.read_csv(folder/'train.csv')
preprocess=ColumnTransformer([
    ('numeric',SimpleImputer(strategy='median',add_indicator=True),numeric),
    ('categorical',Pipeline([('missing',SimpleImputer(strategy='most_frequent')),('encode',OneHotEncoder(handle_unknown='ignore'))]),categorical),
])
model=Pipeline([('prepare',preprocess),('model',RandomForestRegressor(n_estimators=300,max_depth=12,min_samples_leaf=3,random_state=42,n_jobs=-1))])
# Predict a relative change to avoid tying all predictions to the historical price scale.
model.fit(train[features],np.log(train[config['target']]/train['current_price_rub']))
results={}
for split in ['validation','test']:
    frame=pd.read_csv(folder/(split+'.csv'));y=frame[config['target']]
    baseline=frame['current_price_rub']
    prediction=baseline*np.exp(model.predict(frame[features]))
    results[split]={
        'rows':len(frame),'model_mae_rub':mean_absolute_error(y,prediction),
        'model_rmse_rub':float(np.sqrt(mean_squared_error(y,prediction))),
        'baseline_mae_rub':mean_absolute_error(y,baseline),
    }
    pd.DataFrame({'row_id':frame['row_id'],'actual_price_rub':y,'predicted_price_rub':prediction,'baseline_price_rub':baseline}).to_csv(folder/('example_predictions_'+split+'.csv'),index=False)
print(json.dumps(results,ensure_ascii=False,indent=2))
(folder/'example_metrics.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
